var FB_APP_ID = "1915895988671514";
var FB_APP_NAME = "Spotlightmart";
var FB_APP_PERMISSION = ["email", "public_profile"];