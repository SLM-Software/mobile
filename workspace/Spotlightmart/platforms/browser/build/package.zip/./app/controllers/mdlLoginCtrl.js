SpotlightmartApp.controller('mdlLoginCtrl', function ($scope, CordovaService, $modalInstance, UserService) {
    CordovaService.ready.then(function () {
        $scope.username;
        $scope.password;
        
        init();
        
        function init() {
            UserService.initDB();
        }
        
        $scope.login = function() {
            
        }
        
        $scope.facebookLogin = function() {
            facebookConnectPlugin.browserInit("1915895988671514");
            facebookConnectPlugin.login(["public_profile"], 
                function (result) {
                    console.log("FB Result : %o", result);
                },
                function (error) {
                    alert(error);
                }
            );
        }
        
        $scope.cancel = function() {
            $modalInstance.dismiss('cancel');
        }
    });
});
