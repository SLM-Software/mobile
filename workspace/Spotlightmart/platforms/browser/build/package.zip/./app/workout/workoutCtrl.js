CT6App.controller('workoutCtrl', function ($scope, CordovaService, $location, $rootScope, BackExercises, BicepsExercises, ShoulderExercises, CacheService, Configs, Weeks, WorkoutDaysWorkout, WorkoutDaysCompleted, dateService, $filter, $window, $uibModal, $q, $route, $routeParams) {
    CordovaService.ready.then(function () {
    })
});
