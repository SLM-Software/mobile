SpotlightmartApp.controller('personalCtrl', function ($scope, CordovaService, $location, $rootScope) {
    CordovaService.ready.then(function () {
    });
});