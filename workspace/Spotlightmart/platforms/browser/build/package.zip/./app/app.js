angular.module('fsCordova', [])
.service('CordovaService', ['$document', '$q',
  function ($document, $q) {

      var d = $q.defer(),
          resolved = false;

      var self = this;
      this.ready = d.promise;

      document.addEventListener('deviceready', function () {
          resolved = true;
          d.resolve(window.cordova);
      });

      document.addEventListener("backbutton", function() {
          navigator.notification.confirm(
            'Do you really want to exit this app?',
            function (btnIndex) {
                if (btnIndex==1) // OK
                    navigator.app.exitApp();
            },
            "Confirm exit",
            ['OK', 'Cancel']
          );
      }, false);
      
      // Check to make sure we didn't miss the 
      // event (just in case)
      setTimeout(function () {
          if (!resolved) {
              if (window.cordova) d.resolve(window.cordova);
          }
      }, 3000);
  }]);


var SpotlightmartApp = angular.module('SpotlightmartApp', ['fsCordova', 'ngRoute','ui.bootstrap','angular-cardflow','ngTouch']);

SpotlightmartApp.filter('substring', function() {
    return function(str, start, end) {
        return str.substring(start, end);
    }
});
SpotlightmartApp.filter('roundto5', function() {
    return function(num) {
        return 5 * Math.round(num/5);
    }
});
SpotlightmartApp.filter('replace', function() {
    return function(oldstr, newstr) {
        return oldstr.replace(/oldstr/g, newstr);
    }
});

SpotlightmartApp.config(function ($routeProvider, $locationProvider) {
    $routeProvider
        .when('/Home/', {
            templateUrl: 'app/views/home.html',
            controller: 'homeCtrl'
        })
        .when('/Setup', {
            templateUrl: 'app/views/setup.html',
            controller: 'setupCtrl'
        })
        .when('/EditAccessory/:exerciseType',{
            templateUrl: 'app/views/editAccessory.html',
            controller: 'editAccessoryCtrl'
        })
        .when('/EditOptional', {
            templateUrl: 'app/views/editOptional.html',
            controller: 'editOptionalCtrl'
        })
        .when('/LastWeek', {
            templateUrl: 'app/views/modalLastWeek.html',
            controller: 'lastWeekCtrl'
        })
        .when('/Calendar', {
            templateUrl: 'app/views/calendar.html',
            controller: 'calendarCtrl'
        })
    .otherwise({
        redirectTo: '/Home/'+null
    });
});

SpotlightmartApp.controller('indexCtrl', function ($scope, CordovaService, $location, $rootScope) {
    // Event Handler for the left and right nav button
    $scope.LeftNavButtonClick = function () {
        if ($location.path().indexOf('Home') > -1) {
            $location.path('/Calendar');
        }
        else if ($location.path() == '/Setup' || $location.path() == '/Calendar') {
            $location.path('/Home');
        }
        else {
            $location.path('/Setup');
        }
    };
    $scope.RightNavButtonClick = function () {
        if ($location.path().indexOf('Home') > -1) {
            $location.path('/Setup');
        }
        else {
            $location.path('/Home');
        }
    };
    // Updating the left and right nav button icon disable/enable
    $scope.tcdevicePixelRatio = window.devicePixelRatio;

    //$scope.leftNavButtonCss = 'btnHide';
    //$scope.rightNavButtonCss = 'btnHide';

    $rootScope.$on('$locationChangeSuccess', function () {
        //alert('$locationChangeSuccess changed to'+$location.path());
        if ($location.path().indexOf('Home') > -1) {
            $scope.title = '6WP';
            $scope.leftNavDivCss = "col-xs-3 text-left";
            $scope.leftNavSpanCss = 'glyphicon glyphicon-calendar';
            $scope.rightNavDivCss = "col-xs-3 text-right";
            $scope.rightNavSpanCss = 'glyphicon glyphicon-cog';
        }
        else if ($location.path() == '/Setup') {
            $scope.title = 'Setup';
            $scope.leftNavDivCss = "col-xs-3 text-left";
            $scope.leftNavSpanCss = 'glyphicon glyphicon-chevron-left';
            $scope.rightNavDivCss = "col-xs-3 text-right hide";
            $scope.rightNavSpanCss = 'glyphicon glyphicon-cog';
        }
        else if ($location.path() == '/Calendar') {
            $scope.title = 'Calendar';
            $scope.leftNavDivCss = "col-xs-3 text-left";
            $scope.leftNavSpanCss = 'glyphicon glyphicon-chevron-left';
            $scope.rightNavDivCss = "col-xs-3 text-right hide";
            $scope.rightNavSpanCss = 'glyphicon glyphicon-cog';
        }
        else if ($location.path() == '/EditAccessory') {
            $scope.title = 'Accessory';
            $scope.leftNavDivCss = "col-xs-3 text-left";
            $scope.leftNavSpanCss = 'glyphicon glyphicon-chevron-left';
            $scope.rightNavDivCss = "col-xs-3 text-right hide";
            $scope.rightNavSpanCss = 'glyphicon glyphicon-cog';            
        }
        else if ($location.path() == '/EditOptional') {
            $scope.title = 'Optional';
            $scope.leftNavDivCss = "col-xs-3 text-left";
            $scope.leftNavSpanCss = 'glyphicon glyphicon-chevron-left';
            $scope.rightNavDivCss = "col-xs-3 text-right hide";
            $scope.rightNavSpanCss = 'glyphicon glyphicon-cog';            
        }        
    });
});
